"""\
Dreamweaver Template Service

Caches templates in memory for faster re-use.
"""

import logging
import os

from bn import AttributeDict, uniform_path
from dreamweavertemplate import DWT

log = logging.getLogger(__name__)

class DreamweaverTemplateService(object):

    def __init__(self, directory):
        self.directory = directory
        self._cache = {}

    @staticmethod
    def config(flow, name):
        if not flow.config.option_group.has_key(name):
            directory = os.path.join(
                flow.config.app.app_dir,
                'static',  
                'Templates',
            )
        else:
            directory = flow.config.option_group[name]['directory']
        flow.config[name] = AttributeDict(
            dict(directory=directory)
        )
        return flow.config[name]

    @staticmethod
    def create(flow, name, config=None):
        if config is None:
            conifg = DreamweaverTemplateService.config(flow, name)
        return DreamweaverTemplateService(config.directory)

    def start(self, flow, name):

        def render(
            template, 
            regions=None,
            new_path=None,
            template_path='Templates',
        ):
            if regions is None:
                regions = {}
            if new_path is None:
                new_path = flow.http.environ['PATH_INFO'][1:]
            if not template.startswith('/'):
                template = uniform_path(
                    os.path.join(
                        self.directory,
                        template,
                    )
                )
            if not self._cache.has_key(template):
                fp = open(template, 'rb')
                output = fp.read()
                fp.close()
                self._cache[template] = output
            tmpl = DWT(template=self._cache[template])
            for k, v in regions.items():
                tmpl.set(k, v)
            filename=uniform_path(
                os.path.join(self.directory, '../', new_path)
            )
            template_path=template
            if not os.path.exists(template_path):
                raise Exception('No such template %r'%template_path)
            return tmpl.save_as_page(
                new_path=uniform_path(
                    os.path.join(self.directory, '../', new_path)
                ),
                template_path=uniform_path(
                    os.path.join(self.directory, '../', template_path)
                ),
            )
        flow[name] = AttributeDict(render=render)

