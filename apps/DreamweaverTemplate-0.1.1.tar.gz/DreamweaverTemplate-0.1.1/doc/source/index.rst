0.1.1
+++++

.. include :: ../index.txt

Documentation
=============

.. toctree::
   :maxdepth: 2

   manual
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
