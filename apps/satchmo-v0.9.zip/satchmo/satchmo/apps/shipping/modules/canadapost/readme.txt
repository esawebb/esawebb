###############################
# Canada Post Shipping Module #
# Nav Aulakh                  #
# www.navaulakh.com           #
# Dec 14, 2008                #
###############################


See documentation in docs/shipping.txt
