import shipper

def get_methods():
    return [shipper.Shipper()]

