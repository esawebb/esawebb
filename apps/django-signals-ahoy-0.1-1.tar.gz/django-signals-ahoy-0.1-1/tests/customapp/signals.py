import django.dispatch

async_note = django.dispatch.Signal()
