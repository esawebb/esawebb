"""Don't do a thing with the contact info."""

def is_subscribed(contact):
    return False

def update_contact(*args, **kwargs):
    pass
