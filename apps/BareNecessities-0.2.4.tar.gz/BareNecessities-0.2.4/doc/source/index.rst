.. BareNecessitites documentation master file, created by
   sphinx-quickstart on Fri Jul 17 10:42:51 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

0.2.3
+++++

.. include :: ../index.txt

Documentation
=============

.. toctree::
   :maxdepth: 2

   manual
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

