API Documentation
+++++++++++++++++

.. automodule:: bn
   :members:
   :undoc-members:

