About
-----

Django-Livesettings is a project split from the `Satchmo Project`_.  It provides the ability to configure settings via an admin interface, rather than by editing "settings.py".

.. _`Satchmo Project`: http://www.satchmoproject.com
